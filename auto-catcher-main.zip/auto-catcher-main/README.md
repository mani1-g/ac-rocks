# Self-Bot-Discord

------------------------------------------------------------
### ability

-Alldm

-Ascii

-kiss

-Time

-typing 

-weather

-joinv

------------------------------------------------------------
#### Libraries participating in this project

-discord.js-self

-quick.db

-weather-js

  ------------------------------------------------------------

# Install

-Download and Install [node.js](https://nodejs.org/en/download/)
 
 -Download the file using the following command

```
git clone <link>
```

 -Use the following commands to go into the file and install the required libraries

```
cd <File location>

npm install

```


 -Enter the config.json file and change the following
```css 
   "botstat":{
        "tokenbot":" ",
        "prefix":"md!",
        "botID":" ",
        "ownerID":" ",
        
```


 -And after doing all the work and saving the information using the following command, you turn on the Bot 
 
``` 
node .
```
 
---------------------------------------------

## How Find account API token

Hold the (Ctrl + Shift + I) keys inside the Discord app

Then go to the (Network) tab in the page that opens

And press the (Ctrl + R) key and search for the word api in the search field

Go to the option in the science name list

Then go to the Headers tab and at the bottom of your token list is your account

Copy it and paste it in the config.json file

Example for token API : {mfa.jxxxSfsexxxBtHUrsixxxw1MD2XedIuwexxxFh7fdTAQsFxxx8Wkrjfwmxxxl5zvxxxhFkxxygwjdxxxaNp}
